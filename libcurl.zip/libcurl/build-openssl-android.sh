#!/bin/bash -e

OPENSSL_VERSION=${1:-"1.0.2g"}
OPENSSL_TARBALL=openssl-${OPENSSL_VERSION}.tar.gz
OPENSSL_DIR=openssl-${OPENSSL_VERSION}
OPENSSL_BUILD_LOG=openssl-${OPENSSL_VERSION}.log
APP_ABI="armeabi-v7a"

if [ $# == 2 ]; then
	APP_ABI=$2
fi

echo "before setenv_android" $APP_ABI


# Download setenv_android.sh
if [ ! -e setenv-android.sh ]; then 
	echo "Downloading setenv_android.sh..."
	curl -# -o setenv-android.sh http://wiki.openssl.org/images/7/70/Setenv-android.sh
	chmod a+x setenv-android.sh
fi

# Download openssl source
if [ ! -e ${OPENSSL_TARBALL} ]; then
	echo "Downloading openssl-${OPENSSL_VERSION}.tar.gz..."
	curl -# -O http://www.openssl.org/source/${OPENSSL_TARBALL}
fi

# Verify the source file
if [ ! -e ${OPENSSL_TARBALL}.sha1 ]; then
	echo -n "Verifying...	"
	curl -o ${OPENSSL_TARBALL}.sha1 -s http://www.openssl.org/source/${OPENSSL_TARBALL}.sha1
	CHECKSUM=`cat ${OPENSSL_TARBALL}.sha1`
	ACTUAL=`shasum ${OPENSSL_TARBALL} | awk '{ print \$1 }'`
	if [ "x$ACTUAL" == "x$CHECKSUM" ]; then
		echo "OK"
	else
		echo "FAIL"
		rm -f ${OPENSSL_TARBALL}
		rm -f ${OPENSSL_TARBALL}.sha1
		exit 1
	fi
fi

# Untar the file
if [ ! -e ${OPENSSL_DIR} ]; then
	tar zxf ${OPENSSL_TARBALL}
fi

if [ $APP_ABI = "armeabi" ]; then
	sed -i '' '/OUT=\"\$PREFIX\$OUT\"/i\
	if [ $OUT = \"android-" ]; then 
	' ${OPENSSL_DIR}/config

	sed -i '' '/OUT=\"\$PREFIX\$OUT\"/i\
		OUT="android"
	' ${OPENSSL_DIR}/config

	sed -i '' '/OUT=\"\$PREFIX\$OUT\"/i\
	fi
	' ${OPENSSL_DIR}/config
fi

# Setup the environment
. ./setenv-android.sh $APP_ABI

# Build
echo "Compiling..." $APP_ABI
sslpath=$(pwd)/libs/ssl/${APP_ABI}
cd ${OPENSSL_DIR}
perl -pi -e 's/install: all install_docs install_sw/install: install_docs install_sw/g' Makefile.org
./config shared -no-ssl2 -no-ssl3 -no-comp -no-hw -no-engine --openssldir=${sslpath} > ../${OPENSSL_BUILD_LOG}
make depend >> ../${OPENSSL_BUILD_LOG} 
make all -j10 >> ../${OPENSSL_BUILD_LOG}

# Installing
echo "Installing..."

if [ $APP_ABI = "x86" ]; then
	sudo -E make install CC=$ANDROID_TOOLCHAIN/i686-linux-android-gcc RANLIB=$ANDROID_TOOLCHAIN/i686-linux-android-ranlib  >> ../${OPENSSL_BUILD_LOG}
else
	sudo -E make install CC=$ANDROID_TOOLCHAIN/arm-linux-androideabi-gcc RANLIB=$ANDROID_TOOLCHAIN/arm-linux-androideabi-ranlib  >> ../${OPENSSL_BUILD_LOG}
fi

