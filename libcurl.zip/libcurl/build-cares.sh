#!/bin/sh

# Create the standalone toolchain

rm -rf /tmp/my-android-toolchain

APP_ABI="armeabi-v7a"

if [ $# == 1 ]; then
	APP_ABI=$1
fi

if [ $APP_ABI = "x86" ]; then
	$ANDROID_NDK_ROOT/build/tools/make-standalone-toolchain.sh --system=darwin-x86_64 --platform=android-9 --install-dir=/tmp/my-android-toolchain --ndk-dir=${ANDROID_NDK_ROOT} --toolchain=x86-4.4.3
	export PATH=/tmp/my-android-toolchain/bin:$PATH
	export SYSROOT=/tmp/my-android-toolchain/sysroot
	export CC="/tmp/my-android-toolchain/bin/i686-linux-android-gcc --sysroot $SYSROOT"
else
	$ANDROID_NDK_ROOT/build/tools/make-standalone-toolchain.sh --system=darwin-x86_64 --platform=android-9 --install-dir=/tmp/my-android-toolchain --ndk-dir=${ANDROID_NDK_ROOT} --toolchain=arm-linux-androideabi-4.4.3
	export PATH=/tmp/my-android-toolchain/bin:$PATH
	export SYSROOT=/tmp/my-android-toolchain/sysroot
	export CC="arm-linux-androideabi-gcc --sysroot $SYSROOT"
fi

CARES_TARBALL=c-ares-1.11.0.tar.gz
CARES_DIR=c-ares-1.11.0

# Download the latest release
if [ ! -e ${CARES_TARBALL} ]; then
	curl -O http://c-ares.haxx.se/download/${CARES_TARBALL}
fi

rm -rf ${CARES_DIR}
tar zxf ${CARES_TARBALL}

# Configure
cd ${CARES_DIR} 
echo ${PATH}

echo "Building c-ares...." $APP_ABI

if [ $APP_ABI = "x86" ]; then
	./configure --prefix=$(pwd)/build --host=i686-linux-android --disable-shared
elif [ $APP_ABI = "armeabi-v7a" ]; then
	./configure --prefix=$(pwd)/build --host=arm-linux-androideabi --disable-shared CFLAGS="-march=armv7-a"
elif [ $APP_ABI = "armeabi" ]; then
	./configure --prefix=$(pwd)/build --host=arm-linux-androideabi --disable-shared
fi

# Build and install
make -j10 && make install

