#!/bin/sh

# Create the standalone toolchain

rm -rf /tmp/my-android-toolchain

APP_ABI="armeabi-v7a"

if [ $# == 1 ]; then
	APP_ABI=$1
fi

if [ $1 = "x86" ]; then
	$ANDROID_NDK_ROOT/build/tools/make-standalone-toolchain.sh --system=darwin-x86_64 --platform=android-9 --install-dir=/tmp/my-android-toolchain --ndk-dir=${ANDROID_NDK_ROOT} --toolchain=x86-4.4.3
	export PATH=/tmp/my-android-toolchain/bin:$PATH
	export SYSROOT=/tmp/my-android-toolchain/sysroot
	export CC="/tmp/my-android-toolchain/bin/i686-linux-android-gcc --sysroot $SYSROOT"
else
	$ANDROID_NDK_ROOT/build/tools/make-standalone-toolchain.sh --system=darwin-x86_64 --platform=android-9 --install-dir=/tmp/my-android-toolchain --ndk-dir=${ANDROID_NDK_ROOT} --toolchain=arm-linux-androideabi-4.4.3
	export PATH=/tmp/my-android-toolchain/bin:$PATH
	export SYSROOT=/tmp/my-android-toolchain/sysroot
	export CC="arm-linux-androideabi-gcc --sysroot $SYSROOT"
fi

CURL_TARBALL=curl-7.48.0.tar.gz
CURL_DIR=curl-7.48.0

rm -rf ${CURL_DIR}
tar zxf ${CURL_TARBALL}

rootpath=$(pwd)
# Configure
cd ${CURL_DIR} 
echo ${PATH}

echo "Building curl...." $APP_ABI

if [ $APP_ABI = "x86" ]; then
	./configure --prefix=$(pwd)/build --host=i686-linux-android --with-ssl=${rootpath}/libs/ssl/x86 --enable-ares=${rootpath}/libs/c-ares/x86
elif [ $APP_ABI = "armeabi-v7a" ]; then
	./configure --prefix=$(pwd)/build --host=arm-linux-androideabi --with-ssl=${rootpath}/libs/ssl/armeabi-v7a --enable-ares=${rootpath}/libs/c-ares/armeabi-v7a CFLAGS="-march=armv7-a"
elif [ $APP_ABI = "armeabi" ]; then
	./configure --prefix=$(pwd)/build --host=arm-linux-androideabi --with-ssl=${rootpath}/libs/ssl/armeabi --enable-ares=${rootpath}/libs/c-ares/armeabi
fi

# Build and install
make -j10 && make install

